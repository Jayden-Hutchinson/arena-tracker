export class MatchHistory {
  constructor() {
    this.matches = {};
  }
}
