function Player() {
  return (
    <div className="Player">
      <ChampionStats />
      <Augments />
      <Items />
      <KillDeathRatio />
      <DamageDealt />
    </div>
  );
}
export default Player;
