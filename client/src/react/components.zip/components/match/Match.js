function Match() {
  return (
    <div className="Match">
      <Player />
      <Player />
      <ChampionStats />
      <Augments />
      <Items />
      <DamageDealt />
    </div>
  );
}
export default Match;
