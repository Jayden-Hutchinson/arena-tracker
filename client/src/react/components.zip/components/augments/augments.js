function Augments(augments) {
  return (
    <div className="Augments">
      {augments.map((augment, index) => {
        <img
          key={index}
          className="Augment"
          src={augment.img}
          alt={augment.name}
        />;
      })}
    </div>
  );
}
export default Augments;
